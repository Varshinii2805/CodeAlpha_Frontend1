// Image List

let images = [
    "c:\Users\Varshini.M\Downloads\ei.jpg",
    "c:\Users\Varshini.M\Downloads\ch.jpg",
    "c:\Users\Varshini.M\Downloads\ta.jpg",
    "c:\Users\Varshini.M\Downloads\be.jpg",
    "c:\Users\Varshini.M\Downloads\ku.jpg",
    "c:\Users\Varshini.M\Downloads\se.jpg",
    "c:\Users\Varshini.M\Downloads\bu.jpg"
];

let currentIndex = 0;

// Open Lightbox

function openLightbox(index) {

    currentIndex = index;

    document.getElementById("lightbox").style.display = "flex";

    document.getElementById("lightbox-img").src =
        images[currentIndex];
}

// Close Lightbox

function closeLightbox() {

    document.getElementById("lightbox").style.display = "none";
}

// Next / Previous

function changeImage(step) {

    currentIndex += step;

    if (currentIndex < 0) {
        currentIndex = images.length - 1;
    }

    if (currentIndex >= images.length) {
        currentIndex = 0;
    }

    document.getElementById("lightbox-img").src =
        images[currentIndex];
}